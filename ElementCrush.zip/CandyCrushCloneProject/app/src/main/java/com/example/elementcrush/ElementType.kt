package com.example.elementcrush

enum class ElementType(val resId: Int) {
    FIRE(R.drawable.fire),
    WATER(R.drawable.water),
    EARTH(R.drawable.earth),
    AIR(R.drawable.wind);

    companion object {
        // Randomly choose an ElementType
        fun random(): ElementType {
            val values = values()
            return values[(values.indices).random()]
        }
    }
}