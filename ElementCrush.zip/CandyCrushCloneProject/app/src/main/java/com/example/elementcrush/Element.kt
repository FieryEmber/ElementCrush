package com.example.elementcrush

data class Element(val type: ElementType)