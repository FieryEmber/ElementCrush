package com.example.elementcrush

import android.os.Bundle
import android.os.CountDownTimer
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var gridLayout: GridLayout
    private lateinit var scoreText: TextView
    private lateinit var timerText: TextView
    private lateinit var restartButton: Button
    private lateinit var highScoreText: TextView
    private var highScore = 0

    private var gridSize = 8
    private var elements: Array<Array<Element?>> = Array(gridSize) { arrayOfNulls(gridSize) }
    private var imageViews: Array<Array<ImageView?>> = Array(gridSize) { arrayOfNulls(gridSize) }

    private var selected: Pair<Int, Int>? = null
    private var score = 0
    private var timer: CountDownTimer? = null
    private var timeLeft: Long = 60000
    private var gameActive = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI components
        gridLayout = findViewById(R.id.gridLayout)
        scoreText = findViewById(R.id.scoreText)
        timerText = findViewById(R.id.timerText)
        restartButton = findViewById(R.id.restartButton)

        highScoreText = findViewById(R.id.highScoreText)

        val prefs = getSharedPreferences("gamePrefs", MODE_PRIVATE)
        highScore = prefs.getInt("highScore", 0)
        highScoreText.text = "High Score: $highScore"

        // Restart button functionality
        restartButton.setOnClickListener { resetGame() }

        // Setup and start the game
        setupBoard()
        startTimer()
    }

    private fun setupBoard() {
        gridLayout.removeAllViews()
        gridLayout.columnCount = gridSize
        gridLayout.rowCount = gridSize

        val displayMetrics = resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels
        val screenHeight = displayMetrics.heightPixels

        val imageSize = Math.min(screenWidth, screenHeight) / gridSize // Adjust image size based on screen size

        for (i in 0 until gridSize) {
            for (j in 0 until gridSize) {
                // Ensure unique element types to prevent initial matches
                var type: ElementType
                do {
                    type = ElementType.random()
                } while (createsMatchAt(i, j, type))

                elements[i][j] = Element(type)

                val imageView = ImageView(this)
                imageView.layoutParams = GridLayout.LayoutParams().apply {
                    width = imageSize
                    height = imageSize
                    setMargins(2, 2, 2, 2)  // Optional: add some margin for better spacing
                }

                imageView.setImageResource(type.resId)
                imageView.setOnClickListener { handleClick(i, j) }

                imageViews[i][j] = imageView
                gridLayout.addView(imageView)
            }
        }
    }

    private fun createsMatchAt(i: Int, j: Int, type: ElementType): Boolean {
        elements[i][j] = Element(type)
        val match = isPartOfMatch(i, j)
        elements[i][j] = null
        return match
    }

    private fun isPartOfMatch(i: Int, j: Int): Boolean {
        val type = elements[i][j]?.type ?: return false
        return (j >= 2 && type == elements[i][j - 1]?.type && type == elements[i][j - 2]?.type) ||
                (i >= 2 && type == elements[i - 1][j]?.type && type == elements[i - 2][j]?.type)
    }

    private fun handleClick(i: Int, j: Int) {
        if (!gameActive) return

        selected?.let { (x, y) ->
            if ((x == i && Math.abs(y - j) == 1) || (y == j && Math.abs(x - i) == 1)) {
                swap(x, y, i, j)
                checkMatches()
            }
            selected = null
        } ?: run {
            selected = Pair(i, j)
        }
    }

    private fun swap(x1: Int, y1: Int, x2: Int, y2: Int) {
        val temp = elements[x1][y1]
        elements[x1][y1] = elements[x2][y2]
        elements[x2][y2] = temp
        updateBoard()
    }

    private fun checkMatches() {
        val matched = mutableSetOf<Pair<Int, Int>>()

        // Horizontal check
        for (i in 0 until gridSize) {
            for (j in 0 until gridSize - 2) {
                val t = elements[i][j]?.type
                if (t != null && t == elements[i][j + 1]?.type && t == elements[i][j + 2]?.type) {
                    matched.addAll(listOf(Pair(i, j), Pair(i, j + 1), Pair(i, j + 2)))
                }
            }
        }

        // Vertical check
        for (j in 0 until gridSize) {
            for (i in 0 until gridSize - 2) {
                val t = elements[i][j]?.type
                if (t != null && t == elements[i + 1][j]?.type && t == elements[i + 2][j]?.type) {
                    matched.addAll(listOf(Pair(i, j), Pair(i + 1, j), Pair(i + 2, j)))
                }
            }
        }

        // Handle matches
        if (matched.isNotEmpty()) {
            for ((i, j) in matched) elements[i][j] = null
            score += matched.size
            scoreText.text = "Score: $score"
            applyGravity()
        }

        if (score > highScore) {
            highScore = score
            highScoreText.text = "High Score: $highScore"
            val editor = getSharedPreferences("gamePrefs", MODE_PRIVATE).edit()
            editor.putInt("highScore", highScore)
            editor.apply()
        }
    }

    private fun applyGravity() {
        for (j in 0 until gridSize) {
            var writeRow = gridSize - 1
            for (i in gridSize - 1 downTo 0) {
                elements[i][j]?.let {
                    elements[writeRow][j] = it
                    if (writeRow != i) elements[i][j] = null
                    writeRow--
                }
            }
            for (i in writeRow downTo 0) {
                val type = ElementType.random()
                elements[i][j] = Element(type)
            }
        }
        updateBoard()
        checkMatches()
    }

    private fun updateBoard() {
        for (i in 0 until gridSize) {
            for (j in 0 until gridSize) {
                elements[i][j]?.let { element ->
                    imageViews[i][j]?.setImageResource(element.type.resId)
                }
            }
        }
    }

    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(timeLeft, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeLeft = millisUntilFinished
                timerText.text = "Time: ${timeLeft / 1000}s"
            }

            override fun onFinish() {
                gameActive = false
                Toast.makeText(this@MainActivity, "Game Over! Score: $score", Toast.LENGTH_LONG).show()
                restartButton.visibility = Button.VISIBLE
            }
        }.start()
    }

    private fun resetGame() {
        score = 0
        timeLeft = 60000
        scoreText.text = "Score: $score"
        restartButton.visibility = Button.GONE
        gameActive = true
        setupBoard()
        startTimer()
    }
}